# Forex MACD 11/9/3 — Telegram

Bot de alertas somente leitura para Forex aberto. Não opera, não envia ordens e não usa OTC.

## Arquivos
- `main.py`: monitoramento, candles M1/M5, MACD e Telegram.
- `requirements.txt`: dependências.
- `render.yaml`: configuração de worker no Render.

## Variáveis de ambiente no Render
- `TELEGRAM_TOKEN`: token do bot Telegram (mantenha secreto).
- `TELEGRAM_CHAT_ID`: ID do chat que receberá os alertas. Envie `/start` ao bot para descobrir o ID exibido.
- `TWELVE_DATA_API_KEY`: chave da Twelve Data.
- `FOREX_SYMBOLS`: opcional; pares separados por vírgula.

## Importante sobre o provedor
A Twelve Data limita o WebSocket gratuito a símbolos de teste e quantidade limitada de assinaturas. Confira no painel da conta se os sete pares estão liberados. Se algum não estiver, reduza `FOREX_SYMBOLS` aos símbolos autorizados ou use um plano com cobertura WebSocket adequada.

## MACD e alertas
Parâmetros preservados: EMA rápida 11, EMA lenta 9 e sinal 3.
O bot constrói candles a partir dos ticks recebidos e calcula M1 e M5. O alerta de cruzamento é intrabar: ele pode aparecer e desaparecer antes do fechamento da vela. O pré-sinal é apenas aviso de aproximação; não é confirmação de entrada.

## Deploy
1. Crie/atualize o repositório GitHub com estes arquivos.
2. No Render, crie um Background Worker ligado ao repositório (ou use o `render.yaml`).
3. Cadastre as variáveis secretas.
4. Faça deploy e confira os logs.
5. Abra o bot no Telegram e envie `/start`.

## Segurança
Nunca coloque token do Telegram ou chave da Twelve Data no código, GitHub ou mensagens públicas. Se um token antigo foi exposto, revogue-o no BotFather e use um novo.
