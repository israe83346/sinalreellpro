import os
import json
import asyncio
import logging
from collections import deque
from datetime import datetime, timezone

import httpx
import websockets
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

# ============================================================
# FOREX MACD 11/9/3 - ALERTAS TELEGRAM - SOMENTE LEITURA
# Dados: Twelve Data (Forex aberto). Sem OTC e sem ordens.
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)
log = logging.getLogger("forex-macd-bot")

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()
TWELVE_DATA_API_KEY = os.getenv("TWELVE_DATA_API_KEY", "").strip()

# Sete pares principais. Edite SYMBOLS no Render se desejar.
SYMBOLS = [
    s.strip().upper()
    for s in os.getenv(
        "FOREX_SYMBOLS",
        "EUR/USD,GBP/USD,USD/JPY,AUD/USD,USD/CAD,USD/CHF,NZD/USD"
    ).split(",")
    if s.strip()
]

FAST = 11
SLOW = 9
SIGNAL = 3
HISTORY_SIZE = 250
PRE_SIGNAL_COOLDOWN_SECONDS = 55

chat_targets = set()
if TELEGRAM_CHAT_ID:
    chat_targets.add(TELEGRAM_CHAT_ID)

# Um candle por timeframe; os preços recebidos por tick atualizam o candle aberto.
class CandleStream:
    def __init__(self, minutes: int, seed_closes=None):
        self.minutes = minutes
        self.seconds = minutes * 60
        self.closes = deque(seed_closes or [], maxlen=HISTORY_SIZE)
        self.bucket = None
        self.open = None
        self.high = None
        self.low = None
        self.close = None
        self.last_pre_alert_bucket = None
        self.last_cross_alert_bucket = None

    def update(self, timestamp: float, price: float):
        bucket = int(timestamp // self.seconds) * self.seconds
        completed = False

        if self.bucket is None:
            self.bucket = bucket
            self.open = self.high = self.low = self.close = price
        elif bucket != self.bucket:
            if bucket > self.bucket and self.close is not None:
                self.closes.append(self.close)
                completed = True
            self.bucket = bucket
            self.open = self.high = self.low = self.close = price
        else:
            self.high = max(self.high, price)
            self.low = min(self.low, price)
            self.close = price

        return completed, self.bucket, self.close

    def live_closes(self):
        values = list(self.closes)
        if self.close is not None:
            values.append(self.close)
        return values


def ema(values, period):
    if len(values) < period:
        return None
    alpha = 2.0 / (period + 1.0)
    result = sum(values[:period]) / period
    for value in values[period:]:
        result = alpha * value + (1.0 - alpha) * result
    return result


def macd_snapshot(closes):
    # Preserva exatamente os parâmetros solicitados: EMA 11, EMA 9, sinal 3.
    if len(closes) < max(FAST, SLOW) + SIGNAL + 3:
        return None

    macd_values = []
    for end in range(max(FAST, SLOW), len(closes) + 1):
        fast_ema = ema(closes[:end], FAST)
        slow_ema = ema(closes[:end], SLOW)
        if fast_ema is not None and slow_ema is not None:
            macd_values.append(fast_ema - slow_ema)

    if len(macd_values) < SIGNAL + 2:
        return None

    signal_values = []
    for end in range(SIGNAL, len(macd_values) + 1):
        signal_values.append(ema(macd_values[:end], SIGNAL))

    if len(signal_values) < 2:
        return None

    macd_now = macd_values[-1]
    signal_now = signal_values[-1]
    macd_prev = macd_values[-2]
    signal_prev = signal_values[-2]
    hist_now = macd_now - signal_now
    hist_prev = macd_prev - signal_prev
    return {
        "macd": macd_now,
        "signal": signal_now,
        "hist": hist_now,
        "prev_hist": hist_prev,
    }


def fmt_price(price):
    return f"{price:.5f}" if price < 100 else f"{price:.3f}"


async def send_alert(app, text):
    targets = set(chat_targets)
    if not targets:
        log.warning("Sem CHAT_ID. Abra o bot no Telegram e envie /start.")
        return
    for chat_id in targets:
        try:
            await app.bot.send_message(chat_id=int(chat_id), text=text)
        except Exception:
            log.exception("Falha ao enviar alerta para chat_id=%s", chat_id)


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = str(update.effective_chat.id)
    chat_targets.add(chat_id)
    await update.message.reply_text(
        "Bot Forex MACD 11/9/3 conectado!\n\n"
        "Mercado: Forex aberto (sem OTC)\n"
        "Timeframes: M1 e M5\n"
        "Alertas: pré-sinal e cruzamento em tempo real\n"
        "Execução: somente alertas; nenhuma ordem é enviada.\n\n"
        f"Chat ID detectado: {chat_id}\n"
        "Mantenha TELEGRAM_CHAT_ID configurado no Render para preservar "
        "o destino após reinicializações."
    )


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Status do bot: processo ativo.\n"
        f"Pares configurados: {', '.join(SYMBOLS)}\n"
        "Indicador: MACD EMA 11/9/3 | M1 + M5\n"
        "Fonte: Twelve Data Forex."
    )


async def load_history(symbol):
    url = "https://api.twelvedata.com/time_series"
    params = {
        "symbol": symbol,
        "interval": "1min",
        "outputsize": 250,
        "apikey": TWELVE_DATA_API_KEY,
        "format": "JSON",
    }
    async with httpx.AsyncClient(timeout=25) as client:
        response = await client.get(url, params=params)
        response.raise_for_status()
        data = response.json()

    if data.get("status") == "error" or "values" not in data:
        raise RuntimeError(
            f"{symbol}: Twelve Data não retornou candles: "
            f"{data.get('message', data)}"
        )

    rows = list(reversed(data["values"]))
    one_minute = []
    for row in rows:
        try:
            dt = datetime.strptime(row["datetime"], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            dt = datetime.strptime(row["datetime"], "%Y-%m-%d")
        dt = dt.replace(tzinfo=timezone.utc)
        one_minute.append((dt.timestamp(), float(row["close"])))

    # M1: fecha histórico. O tick atual abrirá/atualizará o candle em formação.
    m1_closes = [close for _, close in one_minute]

    # M5: agrupa candles M1 pela janela UTC de cinco minutos e usa o último close.
    grouped = {}
    for ts, close in one_minute:
        bucket = int(ts // 300) * 300
        grouped[bucket] = close
    m5_closes = [grouped[k] for k in sorted(grouped)]

    return m1_closes, m5_closes


async def monitor_market(app):
    streams = {}
    for symbol in SYMBOLS:
        m1, m5 = await load_history(symbol)
        streams[symbol] = {
            1: CandleStream(1, m1),
            5: CandleStream(5, m5),
        }
        log.info(
            "Histórico carregado: %s | M1=%s candles | M5=%s candles",
            symbol, len(m1), len(m5)
        )

    url = f"wss://ws.twelvedata.com/v1/quotes/price?apikey={TWELVE_DATA_API_KEY}"

    while True:
        try:
            log.info("Conectando ao fluxo Forex da Twelve Data...")
            async with websockets.connect(
                url, ping_interval=20, ping_timeout=20, close_timeout=10
            ) as ws:
                await ws.send(json.dumps({
                    "action": "subscribe",
                    "params": {"symbols": ",".join(SYMBOLS)}
                }))

                async for raw in ws:
                    message = json.loads(raw)
                    event = message.get("event")

                    if event == "subscribe-status":
                        log.info("Status da assinatura: %s", message)
                        if message.get("fails"):
                            log.error(
                                "Símbolos não autorizados/indisponíveis: %s",
                                message["fails"]
                            )
                    elif event == "error":
                        log.error("Erro do provedor: %s", message)
                    elif event != "price":
                        continue

                    symbol = message.get("symbol", "").upper()
                    if symbol not in streams:
                        continue

                    try:
                        price = float(message["price"])
                        ts = float(message.get("timestamp", datetime.now(
                            timezone.utc
                        ).timestamp()))
                    except (KeyError, TypeError, ValueError):
                        continue

                    for tf, stream in streams[symbol].items():
                        _, bucket, live_close = stream.update(ts, price)
                        snapshot = macd_snapshot(stream.live_closes())
                        if snapshot is None:
                            continue

                        hist = snapshot["hist"]
                        prev_hist = snapshot["prev_hist"]
                        direction = None
                        if prev_hist <= 0 < hist:
                            direction = "CALL"
                        elif prev_hist >= 0 > hist:
                            direction = "PUT"

                        # Cruzamento intrabar: alerta no primeiro tick que cruza.
                        # Pode deixar de existir antes do fechamento do candle.
                        if direction and stream.last_cross_alert_bucket != bucket:
                            stream.last_cross_alert_bucket = bucket
                            await send_alert(
                                app,
                                f"🚨 MACD 11/9/3 — {direction}\n"
                                f"Par: {symbol}\n"
                                f"Timeframe: M{tf}\n"
                                f"Preço: {fmt_price(price)}\n"
                                f"Hora UTC: {datetime.fromtimestamp(ts, timezone.utc):%H:%M:%S}\n"
                                "Cruzamento detectado com a vela em formação.\n"
                                "Atenção: sinal intrabar pode reverter antes do fechamento."
                            )

                        # Pré-sinal: histograma se aproximando de zero em duas leituras.
                        approaching = abs(hist) < abs(prev_hist)
                        if (
                            approaching
                            and stream.last_pre_alert_bucket != bucket
                            and abs(hist) <= max(abs(price) * 0.000015, 0.0000001)
                        ):
                            stream.last_pre_alert_bucket = bucket
                            possible = "CALL" if hist < 0 else "PUT"
                            await send_alert(
                                app,
                                f"⚠️ PRÉ-SINAL MACD 11/9/3 — possível {possible}\n"
                                f"Par: {symbol}\n"
                                f"Timeframe: M{tf}\n"
                                f"Preço: {fmt_price(price)}\n"
                                "Histograma aproximando-se de zero. Aguarde confirmação."
                            )

        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.exception("Fluxo de mercado caiu: %s. Reconectando em 10s.", exc)
            await asyncio.sleep(10)


async def main():
    if not TELEGRAM_TOKEN:
        raise RuntimeError("Configure TELEGRAM_TOKEN nas variáveis do Render.")
    if not TWELVE_DATA_API_KEY:
        raise RuntimeError("Configure TWELVE_DATA_API_KEY nas variáveis do Render.")
    if not SYMBOLS:
        raise RuntimeError("FOREX_SYMBOLS está vazio.")

    application = Application.builder().token(TELEGRAM_TOKEN).build()
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("status", status_command))

    await application.initialize()
    await application.start()
    if application.updater is None:
        raise RuntimeError("Updater do Telegram não foi inicializado.")

    await application.updater.start_polling(drop_pending_updates=True)
    log.info("Bot Telegram iniciado. Envie /start ao bot.")

    market_task = asyncio.create_task(monitor_market(application))
    try:
        await market_task
    finally:
        market_task.cancel()
        await application.updater.stop()
        await application.stop()
        await application.shutdown()


if __name__ == "__main__":
    asyncio.run(main())
